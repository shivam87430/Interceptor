package com.spring.demo.interceptor;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Interceptor extends HandlerInterceptorAdapter {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String username=request.getParameter("username");
        String password=request.getParameter("password");
       if(username.equals("shivam") && password.equals("shivam")){
           HttpSession session=request.getSession();
           session.setAttribute("username",username);
           session.setAttribute("password",password);
           response.sendRedirect("display.jsp");
       }else{
           response.sendRedirect("index.jsp");
       }
        return true;
    }

    /**
     * This implementation is empty.
     */
    @Override
    public void postHandle(
            HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)

            throws Exception {
        System.out.println("posthandle " +request.getRequestURI());
    }

    /**
     * This implementation is empty.
     */
    @Override
    public void afterCompletion(
            HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        System.out.println("afterCompletion " +request.getRequestURI());
    }

}
